export const TOKEN = {
    SET_TOKEN: 'SET_TOKEN',
    SET_IS_LOGIN: 'SET_IS_LOGIN'
}